.test <- function() BiocGenerics:::testPackage("DTHybrid")
